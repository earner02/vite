import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Transaction } from '@/types';
import { toast } from '@/components/ui/use-toast';

interface AuthContextType {
  user: User | null;
  isAdmin: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (email: string, password: string, name: string, passcode: string) => Promise<boolean>;
  logout: () => void;
  adminLogin: (password: string) => boolean;
  updateUserWallet: (userId: string, amount: number) => void;
  addTransactionFee: (fee: number) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

const adminCredentials = [
  { username: 'admin1', password: 'SwaziAdmin2024!' },
  { username: 'admin2', password: 'EarnPost@Admin' },
  { username: 'admin3', password: 'Shield$Connect' }
];

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const savedUser = localStorage.getItem('earnpost_user');
    const savedAdmin = localStorage.getItem('earnpost_admin');
    if (savedUser) setUser(JSON.parse(savedUser));
    if (savedAdmin) setIsAdmin(true);
    
    // Initialize admin wallet if not exists
    const adminWallet = localStorage.getItem('earnpost_admin_wallet');
    if (!adminWallet) {
      localStorage.setItem('earnpost_admin_wallet', '100000');
    }
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    const users = JSON.parse(localStorage.getItem('earnpost_users') || '[]');
    const foundUser = users.find((u: User) => u.email === email && u.password === password);
    
    if (!foundUser) {
      toast({ title: 'Error', description: 'Invalid credentials', variant: 'destructive' });
      return false;
    }
    
    if (!foundUser.isApproved) {
      toast({ title: 'Account Pending', description: 'Your account is awaiting admin approval' });
      return false;
    }
    
    if (foundUser.isBlocked) {
      toast({ title: 'Account Blocked', description: 'Your account has been blocked' });
      return false;
    }
    
    setUser(foundUser);
    localStorage.setItem('earnpost_user', JSON.stringify(foundUser));
    return true;
  };

  const register = async (email: string, password: string, name: string, passcode: string): Promise<boolean> => {
    const users = JSON.parse(localStorage.getItem('earnpost_users') || '[]');
    
    if (users.find((u: User) => u.email === email)) {
      toast({ title: 'Error', description: 'Email already exists', variant: 'destructive' });
      return false;
    }
    
    const newUser: User = {
      id: Date.now().toString(),
      email,
      password,
      passcode,
      name,
      wallet: 0,
      isApproved: false,
      isBlocked: false,
      createdAt: new Date()
    };
    
    users.push(newUser);
    localStorage.setItem('earnpost_users', JSON.stringify(users));
    toast({ title: 'Success', description: 'Registration successful! Awaiting admin approval.' });
    return true;
  };

  const logout = () => {
    setUser(null);
    setIsAdmin(false);
    localStorage.removeItem('earnpost_user');
    localStorage.removeItem('earnpost_admin');
  };

  const adminLogin = (password: string): boolean => {
    const validCredential = adminCredentials.find(cred => cred.password === password);
    if (validCredential) {
      setIsAdmin(true);
      localStorage.setItem('earnpost_admin', 'true');
      return true;
    }
    return false;
  };

  const updateUserWallet = (userId: string, amount: number) => {
    const users = JSON.parse(localStorage.getItem('earnpost_users') || '[]');
    const updatedUsers = users.map((u: User) => {
      if (u.id === userId) {
        return { ...u, wallet: u.wallet + amount };
      }
      return u;
    });
    localStorage.setItem('earnpost_users', JSON.stringify(updatedUsers));
    if (user && user.id === userId) {
      const updatedUser = { ...user, wallet: user.wallet + amount };
      setUser(updatedUser);
      localStorage.setItem('earnpost_user', JSON.stringify(updatedUser));
    }
  };

  const addTransactionFee = (fee: number) => {
    const currentAdminWallet = parseFloat(localStorage.getItem('earnpost_admin_wallet') || '100000');
    const newAdminWallet = currentAdminWallet + fee;
    localStorage.setItem('earnpost_admin_wallet', newAdminWallet.toString());
    
    const transaction: Transaction = {
      id: Date.now().toString(),
      fromUserId: 'system',
      toUserId: 'admin',
      amount: fee,
      fee: 0,
      type: 'fee_collection',
      status: 'completed',
      createdAt: new Date()
    };
    
    const transactions = JSON.parse(localStorage.getItem('earnpost_transactions') || '[]');
    transactions.push(transaction);
    localStorage.setItem('earnpost_transactions', JSON.stringify(transactions));
  };

  return (
    <AuthContext.Provider value={{ user, isAdmin, login, register, logout, adminLogin, updateUserWallet, addTransactionFee }}>
      {children}
    </AuthContext.Provider>
  );
};