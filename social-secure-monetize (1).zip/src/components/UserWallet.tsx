import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { User, Transaction } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';
import { Send, History, Wallet } from 'lucide-react';

export const UserWallet: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [recipientId, setRecipientId] = useState('');
  const [amount, setAmount] = useState('');
  const [passcode, setPasscode] = useState('');
  const { user, addTransactionFee } = useAuth();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    const storedUsers = JSON.parse(localStorage.getItem('earnpost_users') || '[]');
    const storedTransactions = JSON.parse(localStorage.getItem('earnpost_transactions') || '[]');
    setUsers(storedUsers);
    setTransactions(storedTransactions.filter((t: Transaction) => 
      t.fromUserId === user?.id || t.toUserId === user?.id
    ));
  };

  const sendMoney = () => {
    if (!user || !recipientId || !amount || !passcode) {
      toast({ title: 'Error', description: 'Please fill all fields', variant: 'destructive' });
      return;
    }

    if (passcode !== user.passcode) {
      toast({ title: 'Error', description: 'Invalid passcode', variant: 'destructive' });
      return;
    }

    const transferAmount = parseFloat(amount);
    const fee = 2;
    const totalAmount = transferAmount + fee;

    if (user.wallet < totalAmount) {
      toast({ title: 'Error', description: 'Insufficient funds', variant: 'destructive' });
      return;
    }

    const recipient = users.find(u => u.id === recipientId);
    if (!recipient) {
      toast({ title: 'Error', description: 'Recipient not found', variant: 'destructive' });
      return;
    }

    const updatedUsers = users.map(u => {
      if (u.id === user.id) {
        return { ...u, wallet: u.wallet - totalAmount };
      }
      if (u.id === recipientId) {
        return { ...u, wallet: u.wallet + transferAmount };
      }
      return u;
    });

    addTransactionFee(fee);

    const transaction: Transaction = {
      id: Date.now().toString(),
      fromUserId: user.id,
      toUserId: recipientId,
      amount: transferAmount,
      fee,
      type: 'p2p',
      status: 'completed',
      createdAt: new Date()
    };

    const allTransactions = JSON.parse(localStorage.getItem('earnpost_transactions') || '[]');
    const updatedTransactions = [...allTransactions, transaction];
    
    setUsers(updatedUsers);
    localStorage.setItem('earnpost_users', JSON.stringify(updatedUsers));
    localStorage.setItem('earnpost_transactions', JSON.stringify(updatedTransactions));
    
    const updatedUser = updatedUsers.find(u => u.id === user.id);
    if (updatedUser) {
      localStorage.setItem('earnpost_user', JSON.stringify(updatedUser));
    }

    setAmount('');
    setRecipientId('');
    setPasscode('');
    toast({ title: 'Success', description: `Sent E${transferAmount} to ${recipient.name} (Fee: E${fee})` });
    
    setTimeout(loadData, 100);
  };

  const getUserName = (userId: string) => {
    const foundUser = users.find(u => u.id === userId);
    return foundUser?.name || 'Unknown';
  };

  const currentUser = users.find(u => u.id === user?.id) || user;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-950 via-blue-900 to-blue-800 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="text-center">
          <div className="flex items-center justify-center mb-4">
            <Wallet className="h-8 w-8 text-yellow-400 mr-2" />
            <h1 className="text-3xl font-bold text-white">My Wallet</h1>
          </div>
          <div className="text-5xl font-bold text-yellow-400 mb-4">
            E{currentUser?.wallet?.toFixed(2) || '0.00'}
          </div>
        </div>

        <Card className="bg-blue-950/90 border-blue-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Send className="h-5 w-5 mr-2" />
              Send Money (E2 Fee)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <select 
              value={recipientId} 
              onChange={(e) => setRecipientId(e.target.value)}
              className="w-full p-2 bg-blue-900/50 border border-blue-600 rounded text-white"
            >
              <option value="">Select Recipient</option>
              {users.filter(u => u.id !== user?.id && u.isApproved && !u.isBlocked).map(u => (
                <option key={u.id} value={u.id}>{u.name} - {u.email}</option>
              ))}
            </select>
            <Input
              type="number"
              placeholder="Amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="bg-blue-900/50 border-blue-600 text-white"
            />
            <Input
              type="password"
              placeholder="Enter your 4-digit passcode"
              value={passcode}
              onChange={(e) => setPasscode(e.target.value)}
              maxLength={4}
              className="bg-blue-900/50 border-blue-600 text-white"
            />
            <Button 
              onClick={sendMoney}
              className="w-full bg-gradient-to-r from-yellow-400 to-red-500 hover:from-yellow-500 hover:to-red-600"
            >
              Send Money
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-blue-950/90 border-blue-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <History className="h-5 w-5 mr-2" />
              Transaction History
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {transactions.length === 0 ? (
                <p className="text-blue-200 text-center py-4">No transactions yet</p>
              ) : (
                transactions.map(tx => (
                  <div key={tx.id} className="flex items-center justify-between p-3 bg-blue-900/30 rounded border border-blue-700">
                    <div>
                      <p className="text-white font-medium">
                        {tx.fromUserId === user?.id ? 'Sent to' : 'Received from'} {' '}
                        {tx.fromUserId === 'admin' ? 'Admin' : getUserName(tx.fromUserId === user?.id ? tx.toUserId : tx.fromUserId)}
                      </p>
                      <p className="text-sm text-blue-200">
                        {new Date(tx.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className={`font-bold ${
                        tx.fromUserId === user?.id ? 'text-red-400' : 'text-yellow-400'
                      }`}>
                        {tx.fromUserId === user?.id ? '-' : '+'}E{tx.amount}
                      </p>
                      {tx.fee > 0 && tx.fromUserId === user?.id && (
                        <p className="text-xs text-blue-300">Fee: E{tx.fee}</p>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};