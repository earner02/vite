import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { Shield, DollarSign } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface AdminLoginProps {
  onClose?: () => void;
}

const adminCredentials = [
  { username: 'admin1', password: 'SwaziAdmin2024!' },
  { username: 'admin2', password: 'EarnPost@Admin' },
  { username: 'admin3', password: 'Shield$Connect' }
];

export const AdminLogin: React.FC<AdminLoginProps> = ({ onClose }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { adminLogin } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validCredential = adminCredentials.find(
      cred => cred.username === username && cred.password === password
    );
    
    if (validCredential) {
      adminLogin(password);
      navigate('/admin');
      if (onClose) onClose();
    } else {
      setError('Invalid admin credentials');
    }
  };

  return (
    <div className="bg-gradient-to-br from-blue-950 via-blue-900 to-blue-800 p-4">
      <Card className="w-full bg-blue-950/90 border-blue-700 backdrop-blur">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center mb-4">
            <div className="relative">
              <Shield className="h-12 w-12 text-white" />
              <DollarSign className="h-6 w-6 text-yellow-400 absolute top-3 left-3" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold text-white mb-2">Admin Portal</CardTitle>
          <p className="text-yellow-400 text-sm font-medium">EARN. SHARE. CONNECT.</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="username" className="text-white">Username</Label>
              <Input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                className="bg-blue-900/50 border-blue-600 text-white placeholder-blue-300"
                placeholder="Enter admin username"
              />
            </div>
            <div>
              <Label htmlFor="password" className="text-white">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="bg-blue-900/50 border-blue-600 text-white placeholder-blue-300"
                placeholder="Enter admin password"
              />
              {error && <p className="text-red-400 text-sm mt-1">{error}</p>}
            </div>
            
            <Button 
              type="submit" 
              className="w-full bg-gradient-to-r from-yellow-400 to-red-500 hover:from-yellow-500 hover:to-red-600 text-white font-semibold"
            >
              Access Admin Panel
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};