import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Post } from '@/types';
import { toast } from '@/components/ui/use-toast';
import { Edit, Trash2, Eye } from 'lucide-react';

export const AdminPostManager: React.FC = () => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [editingPost, setEditingPost] = useState<string | null>(null);
  const [editContent, setEditContent] = useState('');

  useEffect(() => {
    loadPosts();
  }, []);

  const loadPosts = () => {
    const storedPosts = JSON.parse(localStorage.getItem('earnpost_posts') || '[]');
    setPosts(storedPosts);
  };

  const editPost = (postId: string, newContent: string) => {
    const updatedPosts = posts.map(post => {
      if (post.id === postId) {
        return { ...post, content: newContent };
      }
      return post;
    });
    setPosts(updatedPosts);
    localStorage.setItem('earnpost_posts', JSON.stringify(updatedPosts));
    setEditingPost(null);
    setEditContent('');
    toast({ title: 'Success', description: 'Post updated successfully' });
  };

  const deletePost = (postId: string) => {
    const updatedPosts = posts.filter(post => post.id !== postId);
    setPosts(updatedPosts);
    localStorage.setItem('earnpost_posts', JSON.stringify(updatedPosts));
    toast({ title: 'Success', description: 'Post deleted successfully' });
  };

  const startEdit = (post: Post) => {
    setEditingPost(post.id);
    setEditContent(post.content);
  };

  return (
    <div className="space-y-4">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Eye className="h-5 w-5 mr-2" />
          Posts Management ({posts.length})
        </CardTitle>
      </CardHeader>
      
      {posts.map(post => (
        <Card key={post.id} className="bg-blue-950/50 border-blue-700">
          <CardContent className="p-4">
            <div className="flex justify-between items-start mb-3">
              <div>
                <p className="text-white font-medium">{post.authorName}</p>
                <p className="text-sm text-blue-200">{new Date(post.createdAt).toLocaleString()}</p>
              </div>
              <div className="flex space-x-2">
                <Badge className="bg-blue-700 text-white">
                  {post.likes} likes
                </Badge>
                <Badge className="bg-blue-700 text-white">
                  {post.comments?.length || 0} comments
                </Badge>
              </div>
            </div>
            
            {editingPost === post.id ? (
              <div className="space-y-3">
                <Textarea
                  value={editContent}
                  onChange={(e) => setEditContent(e.target.value)}
                  className="bg-blue-900/50 border-blue-600 text-white"
                  rows={3}
                />
                <div className="flex space-x-2">
                  <Button 
                    onClick={() => editPost(post.id, editContent)}
                    size="sm"
                    className="bg-green-600 hover:bg-green-700"
                  >
                    Save
                  </Button>
                  <Button 
                    onClick={() => setEditingPost(null)}
                    size="sm"
                    variant="outline"
                    className="border-blue-600 text-blue-200"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <div>
                <p className="text-white mb-3">{post.content}</p>
                <div className="flex space-x-2">
                  <Button 
                    onClick={() => startEdit(post)}
                    size="sm"
                    className="bg-gradient-to-r from-yellow-400 to-red-500 hover:from-yellow-500 hover:to-red-600"
                  >
                    <Edit className="h-4 w-4 mr-1" />
                    Edit
                  </Button>
                  <Button 
                    onClick={() => deletePost(post.id)}
                    size="sm"
                    variant="destructive"
                  >
                    <Trash2 className="h-4 w-4 mr-1" />
                    Delete
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
      
      {posts.length === 0 && (
        <Card className="bg-blue-950/50 border-blue-700">
          <CardContent className="p-8 text-center">
            <p className="text-blue-200">No posts available</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};