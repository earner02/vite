import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/contexts/AuthContext';
import { Shield, DollarSign, Eye, EyeOff } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

interface AdminLoginModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({ open, onOpenChange }) => {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const { adminLogin } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const success = adminLogin(password);
      if (success) {
        toast({ title: 'Success', description: 'Admin login successful' });
        onOpenChange(false);
        setPassword('');
      } else {
        toast({ title: 'Error', description: 'Invalid admin credentials', variant: 'destructive' });
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-blue-950 border-blue-700 text-white max-w-md">
        <DialogHeader>
          <div className="flex items-center justify-center mb-4">
            <div className="relative">
              <Shield className="h-10 w-10 text-white" />
              <DollarSign className="h-5 w-5 text-yellow-400 absolute top-2.5 left-2.5" />
            </div>
          </div>
          <DialogTitle className="text-center text-xl text-white">Admin Access</DialogTitle>
          <p className="text-yellow-400 text-center text-sm">EARN. SHARE. CONNECT.</p>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="admin-password" className="text-white">Admin Password</Label>
            <div className="relative">
              <Input
                id="admin-password"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="bg-blue-900/50 border-blue-600 text-white placeholder-blue-300 pr-10"
                placeholder="Enter admin password"
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-0 top-0 h-full px-3 text-blue-300 hover:text-white"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </Button>
            </div>
          </div>
          
          <Button 
            type="submit" 
            className="w-full bg-gradient-to-r from-yellow-400 to-red-500 hover:from-yellow-500 hover:to-red-600 text-white font-semibold"
            disabled={loading}
          >
            {loading ? 'Authenticating...' : 'Login as Admin'}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
};