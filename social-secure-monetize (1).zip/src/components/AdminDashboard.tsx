import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { User, Transaction } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';
import { AdminPostManager } from './AdminPostManager';
import { Shield, Users, Wallet, Activity, LogOut, DollarSign, FileText } from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [fundAmount, setFundAmount] = useState('');
  const [selectedUserId, setSelectedUserId] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newPasscode, setNewPasscode] = useState('');
  const [adminWallet, setAdminWallet] = useState(100000);
  const { logout } = useAuth();

  useEffect(() => {
    loadData();
    initializeAdmin();
  }, []);

  const initializeAdmin = () => {
    const storedAdminWallet = localStorage.getItem('earnpost_admin_wallet');
    if (!storedAdminWallet) {
      localStorage.setItem('earnpost_admin_wallet', '100000');
      setAdminWallet(100000);
    } else {
      setAdminWallet(parseFloat(storedAdminWallet));
    }
  };

  const loadData = () => {
    const storedUsers = JSON.parse(localStorage.getItem('earnpost_users') || '[]');
    const storedTransactions = JSON.parse(localStorage.getItem('earnpost_transactions') || '[]');
    setUsers(storedUsers);
    setTransactions(storedTransactions);
  };

  const approveUser = (userId: string) => {
    const updatedUsers = users.map(user => {
      if (user.id === userId) {
        return { ...user, isApproved: true, wallet: 20 };
      }
      return user;
    });
    setUsers(updatedUsers);
    localStorage.setItem('earnpost_users', JSON.stringify(updatedUsers));
    toast({ title: 'Success', description: 'User approved with E20 welcome bonus' });
  };

  const blockUser = (userId: string) => {
    const updatedUsers = users.map(user => {
      if (user.id === userId) {
        return { ...user, isBlocked: !user.isBlocked };
      }
      return user;
    });
    setUsers(updatedUsers);
    localStorage.setItem('earnpost_users', JSON.stringify(updatedUsers));
    toast({ title: 'Success', description: 'User status updated' });
  };

  const updateUserCredentials = (userId: string) => {
    if (!newPassword && !newPasscode) return;
    
    const updatedUsers = users.map(user => {
      if (user.id === userId) {
        return { 
          ...user, 
          password: newPassword || user.password,
          passcode: newPasscode || user.passcode
        };
      }
      return user;
    });
    setUsers(updatedUsers);
    localStorage.setItem('earnpost_users', JSON.stringify(updatedUsers));
    setNewPassword('');
    setNewPasscode('');
    toast({ title: 'Success', description: 'User credentials updated' });
  };

  const fundUser = () => {
    const amount = parseFloat(fundAmount);
    if (!selectedUserId || amount < 3 || amount > 10000) {
      toast({ title: 'Error', description: 'Invalid amount (E3-E10000)', variant: 'destructive' });
      return;
    }

    if (adminWallet < amount) {
      toast({ title: 'Error', description: 'Insufficient admin funds', variant: 'destructive' });
      return;
    }

    const updatedUsers = users.map(user => {
      if (user.id === selectedUserId) {
        return { ...user, wallet: user.wallet + amount };
      }
      return user;
    });
    
    const newAdminWallet = adminWallet - amount;
    setUsers(updatedUsers);
    setAdminWallet(newAdminWallet);
    localStorage.setItem('earnpost_users', JSON.stringify(updatedUsers));
    localStorage.setItem('earnpost_admin_wallet', newAdminWallet.toString());
    
    const transaction: Transaction = {
      id: Date.now().toString(),
      fromUserId: 'admin',
      toUserId: selectedUserId,
      amount,
      fee: 0,
      type: 'admin_fund',
      status: 'completed',
      createdAt: new Date()
    };
    
    const updatedTransactions = [...transactions, transaction];
    setTransactions(updatedTransactions);
    localStorage.setItem('earnpost_transactions', JSON.stringify(updatedTransactions));
    
    setFundAmount('');
    setSelectedUserId('');
    toast({ title: 'Success', description: `User funded with E${amount}` });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-950 via-blue-900 to-blue-800 p-4">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Shield className="h-10 w-10 text-white" />
              <DollarSign className="h-5 w-5 text-yellow-400 absolute top-2.5 left-2.5" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Admin Dashboard</h1>
              <p className="text-yellow-400 text-sm font-medium">EARN. SHARE. CONNECT.</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-white bg-blue-900/50 px-4 py-2 rounded border border-blue-700">
              <span className="text-sm text-yellow-400">Admin Wallet: </span>
              <span className="font-bold text-white">E{adminWallet.toFixed(2)}</span>
            </div>
            <Button 
              onClick={logout} 
              className="bg-gradient-to-r from-yellow-400 to-red-500 hover:from-yellow-500 hover:to-red-600 text-white"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>

        <Tabs defaultValue="users" className="space-y-4">
          <TabsList className="bg-blue-950/50 border border-blue-700">
            <TabsTrigger value="users" className="data-[state=active]:bg-blue-700 text-white">
              <Users className="h-4 w-4 mr-2" />
              Users ({users.length})
            </TabsTrigger>
            <TabsTrigger value="funding" className="data-[state=active]:bg-blue-700 text-white">
              <Wallet className="h-4 w-4 mr-2" />
              Fund Users
            </TabsTrigger>
            <TabsTrigger value="posts" className="data-[state=active]:bg-blue-700 text-white">
              <FileText className="h-4 w-4 mr-2" />
              Posts
            </TabsTrigger>
            <TabsTrigger value="activity" className="data-[state=active]:bg-blue-700 text-white">
              <Activity className="h-4 w-4 mr-2" />
              Activity
            </TabsTrigger>
          </TabsList>

          <TabsContent value="users">
            <div className="grid gap-4">
              {users.map(user => (
                <Card key={user.id} className="bg-blue-950/50 border-blue-700">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <div className="space-y-1">
                        <h3 className="font-semibold text-white">{user.name}</h3>
                        <p className="text-sm text-blue-200">{user.email}</p>
                        <p className="text-sm text-yellow-400">Wallet: E{user.wallet}</p>
                        <p className="text-xs text-blue-300">Password: {user.password}</p>
                        <p className="text-xs text-blue-300">Passcode: {user.passcode}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant={user.isApproved ? 'default' : 'secondary'} className="bg-blue-700">
                          {user.isApproved ? 'Approved' : 'Pending'}
                        </Badge>
                        {user.isBlocked && <Badge variant="destructive">Blocked</Badge>}
                        {!user.isApproved && (
                          <Button onClick={() => approveUser(user.id)} size="sm" className="bg-green-600">
                            Approve
                          </Button>
                        )}
                        <Button 
                          onClick={() => blockUser(user.id)} 
                          size="sm" 
                          className={user.isBlocked ? 'bg-blue-600' : 'bg-red-600'}
                        >
                          {user.isBlocked ? 'Unblock' : 'Block'}
                        </Button>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Input
                        placeholder="New Password"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        className="bg-blue-900/50 border-blue-600 text-white text-xs"
                      />
                      <Input
                        placeholder="New Passcode"
                        value={newPasscode}
                        onChange={(e) => setNewPasscode(e.target.value)}
                        className="bg-blue-900/50 border-blue-600 text-white text-xs"
                      />
                      <Button 
                        onClick={() => updateUserCredentials(user.id)}
                        size="sm"
                        className="bg-gradient-to-r from-yellow-400 to-red-500 text-white"
                      >
                        Update
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="funding">
            <Card className="bg-blue-950/50 border-blue-700">
              <CardHeader>
                <CardTitle className="text-white">Fund User Wallet</CardTitle>
                <p className="text-yellow-400 text-sm">Minimum E3 - Maximum E10,000</p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <select 
                    value={selectedUserId} 
                    onChange={(e) => setSelectedUserId(e.target.value)}
                    className="w-full p-2 bg-blue-900/50 border border-blue-600 rounded text-white"
                  >
                    <option value="">Select User</option>
                    {users.filter(u => u.isApproved).map(user => (
                      <option key={user.id} value={user.id}>{user.name} - {user.email}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <Input
                    type="number"
                    placeholder="Amount (E3 - E10000)"
                    value={fundAmount}
                    onChange={(e) => setFundAmount(e.target.value)}
                    min="3"
                    max="10000"
                    className="bg-blue-900/50 border-blue-600 text-white"
                  />
                </div>
                <Button 
                  onClick={fundUser} 
                  className="bg-gradient-to-r from-yellow-400 to-red-500 hover:from-yellow-500 hover:to-red-600 text-white"
                >
                  Fund User
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="posts">
            <AdminPostManager />
          </TabsContent>

          <TabsContent value="activity">
            <div className="space-y-4">
              {transactions.map(tx => (
                <Card key={tx.id} className="bg-blue-950/50 border-blue-700">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-white font-medium">
                          {tx.type === 'admin_fund' ? 'Admin Funding' : 'P2P Transfer'}
                        </p>
                        <p className="text-sm text-blue-200">
                          Amount: E{tx.amount} {tx.fee > 0 && `(Fee: E${tx.fee})`}
                        </p>
                      </div>
                      <Badge variant={tx.status === 'completed' ? 'default' : 'secondary'} className="bg-blue-700">
                        {tx.status}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};