import React from 'react';
import { Button } from '@/components/ui/button';
import { Shield, Settings } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

interface AdminTabButtonProps {
  onClick: () => void;
}

export const AdminTabButton: React.FC<AdminTabButtonProps> = ({ onClick }) => {
  const { isAdmin } = useAuth();
  
  if (isAdmin) return null;
  
  return (
    <div className="fixed bottom-4 right-4 z-50">
      <Button
        onClick={onClick}
        className="bg-gradient-to-r from-yellow-400 to-red-500 hover:from-yellow-500 hover:to-red-600 text-white font-semibold shadow-lg rounded-full p-3 h-12 w-12"
        size="sm"
      >
        <Shield className="h-5 w-5" />
      </Button>
    </div>
  );
};