import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { UserFeed } from '@/components/UserFeed';
import { UserWallet } from '@/components/UserWallet';
import { AdminTabButton } from '@/components/AdminTabButton';
import { AdminLoginModal } from '@/components/AdminLoginModal';
import { AdminPanel } from '@/components/AdminPanel';
import { Button } from '@/components/ui/button';
import { Shield, DollarSign, LogOut } from 'lucide-react';

export const MainApp: React.FC = () => {
  const { user, isAdmin, logout } = useAuth();
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [activeTab, setActiveTab] = useState<'feed' | 'wallet'>('feed');

  if (isAdmin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-950 via-blue-900 to-blue-800">
        <div className="flex justify-between items-center p-4 border-b border-blue-700">
          <div className="flex items-center">
            <div className="relative mr-3">
              <Shield className="h-6 w-6 text-white" />
              <DollarSign className="h-3 w-3 text-yellow-400 absolute top-1.5 left-1.5" />
            </div>
            <span className="text-white font-bold">EARNPOST ADMIN</span>
          </div>
          <Button onClick={logout} variant="outline" size="sm"
            className="border-blue-600 text-white hover:bg-blue-700">
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
        <AdminPanel />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-950 via-blue-900 to-blue-800">
      <div className="flex justify-between items-center p-4 border-b border-blue-700">
        <div className="flex items-center">
          <div className="relative mr-3">
            <Shield className="h-6 w-6 text-white" />
            <DollarSign className="h-3 w-3 text-yellow-400 absolute top-1.5 left-1.5" />
          </div>
          <div>
            <h1 className="text-white font-bold">EARNPOST</h1>
            <p className="text-yellow-400 text-xs">EARN. SHARE. CONNECT.</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-white text-sm">Welcome, {user?.name}</span>
          <Button onClick={logout} variant="outline" size="sm"
            className="border-blue-600 text-white hover:bg-blue-700">
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>

      <div className="flex">
        <div className="w-16 bg-blue-950/50 border-r border-blue-700 min-h-screen">
          <div className="flex flex-col items-center py-4 space-y-4">
            <Button
              variant={activeTab === 'feed' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab('feed')}
              className="w-10 h-10 p-0"
            >
              📱
            </Button>
            <Button
              variant={activeTab === 'wallet' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab('wallet')}
              className="w-10 h-10 p-0"
            >
              💰
            </Button>
          </div>
        </div>
        
        <div className="flex-1">
          {activeTab === 'feed' && <UserFeed />}
          {activeTab === 'wallet' && <UserWallet />}
        </div>
      </div>

      <AdminTabButton onClick={() => setShowAdminLogin(true)} />
      <AdminLoginModal 
        open={showAdminLogin} 
        onOpenChange={setShowAdminLogin} 
      />
    </div>
  );
};