import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Post, User, Comment } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';
import { Heart, MessageCircle, Share2, Camera, Video, Send } from 'lucide-react';

export const UserFeed: React.FC = () => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [comments, setComments] = useState<Comment[]>([]);
  const [newPost, setNewPost] = useState('');
  const [newComment, setNewComment] = useState<{[key: string]: string}>({});
  const [showCreatePost, setShowCreatePost] = useState(false);
  const { user, addTransactionFee } = useAuth();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    const storedPosts = JSON.parse(localStorage.getItem('earnpost_posts') || '[]');
    const storedUsers = JSON.parse(localStorage.getItem('earnpost_users') || '[]');
    const storedComments = JSON.parse(localStorage.getItem('earnpost_comments') || '[]');
    setPosts(storedPosts.sort((a: Post, b: Post) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
    setUsers(storedUsers);
    setComments(storedComments);
  };

  const createPost = () => {
    if (!newPost.trim() || !user) return;

    const post: Post = {
      id: Date.now().toString(),
      userId: user.id,
      authorName: user.name,
      content: newPost,
      likes: [],
      earnings: 0,
      createdAt: new Date()
    };

    const updatedPosts = [post, ...posts];
    setPosts(updatedPosts);
    localStorage.setItem('earnpost_posts', JSON.stringify(updatedPosts));
    setNewPost('');
    setShowCreatePost(false);
    toast({ title: 'Success', description: 'Post created successfully!' });
  };

  const toggleLike = (postId: string) => {
    if (!user) return;

    const updatedPosts = posts.map(post => {
      if (post.id === postId) {
        const likes = post.likes.includes(user.id)
          ? post.likes.filter(id => id !== user.id)
          : [...post.likes, user.id];
        
        // Add small earning for likes and charge admin fee
        if (!post.likes.includes(user.id)) {
          const earning = 0.10;
          const fee = 0.01;
          post.earnings = (post.earnings || 0) + earning;
          addTransactionFee(fee);
        }
        
        return { ...post, likes };
      }
      return post;
    });

    setPosts(updatedPosts);
    localStorage.setItem('earnpost_posts', JSON.stringify(updatedPosts));
  };

  const addComment = (postId: string) => {
    const commentText = newComment[postId];
    if (!commentText?.trim() || !user) return;

    const comment: Comment = {
      id: Date.now().toString(),
      postId,
      userId: user.id,
      content: commentText,
      createdAt: new Date()
    };

    const updatedComments = [...comments, comment];
    setComments(updatedComments);
    localStorage.setItem('earnpost_comments', JSON.stringify(updatedComments));
    setNewComment({ ...newComment, [postId]: '' });
    
    // Add small earning for comments and charge admin fee
    const updatedPosts = posts.map(post => {
      if (post.id === postId) {
        const earning = 0.05;
        const fee = 0.005;
        addTransactionFee(fee);
        return { ...post, earnings: (post.earnings || 0) + earning };
      }
      return post;
    });
    setPosts(updatedPosts);
    localStorage.setItem('earnpost_posts', JSON.stringify(updatedPosts));
  };

  const getUserName = (userId: string) => {
    const foundUser = users.find(u => u.id === userId);
    return foundUser?.name || 'Unknown User';
  };

  const getPostComments = (postId: string) => {
    return comments.filter(c => c.postId === postId);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-950 via-blue-900 to-blue-800 p-4">
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold text-white">Feed</h1>
          <Button 
            onClick={() => setShowCreatePost(!showCreatePost)}
            className="bg-gradient-to-r from-yellow-400 to-red-500 hover:from-yellow-500 hover:to-red-600"
          >
            Create Post
          </Button>
        </div>

        {showCreatePost && (
          <Card className="bg-blue-950/90 border-blue-700">
            <CardHeader>
              <h3 className="text-white font-semibold">Create New Post</h3>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                placeholder="What's on your mind?"
                value={newPost}
                onChange={(e) => setNewPost(e.target.value)}
                className="bg-blue-900/50 border-blue-600 text-white min-h-[100px]"
              />
              <div className="flex items-center justify-between">
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" className="border-blue-600 text-white">
                    <Camera className="h-4 w-4 mr-2" />
                    Photo
                  </Button>
                  <Button variant="outline" size="sm" className="border-blue-600 text-white">
                    <Video className="h-4 w-4 mr-2" />
                    Video
                  </Button>
                </div>
                <div className="space-x-2">
                  <Button variant="outline" onClick={() => setShowCreatePost(false)} className="border-blue-600 text-white">
                    Cancel
                  </Button>
                  <Button onClick={createPost} className="bg-gradient-to-r from-yellow-400 to-red-500 hover:from-yellow-500 hover:to-red-600">
                    Post
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="space-y-4">
          {posts.map(post => (
            <Card key={post.id} className="bg-blue-950/90 border-blue-700">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Avatar>
                      <AvatarFallback className="bg-yellow-500 text-blue-900">
                        {post.authorName?.charAt(0) || getUserName(post.userId).charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h4 className="font-semibold text-white">{post.authorName || getUserName(post.userId)}</h4>
                      <p className="text-sm text-blue-200">
                        {new Date(post.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="text-yellow-400 text-sm font-medium">
                    E{(post.earnings || 0).toFixed(2)}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-white">{post.content}</p>
                
                <div className="flex items-center space-x-4 pt-2 border-t border-blue-700">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleLike(post.id)}
                    className={`text-blue-200 hover:text-yellow-400 ${
                      post.likes.includes(user?.id || '') ? 'text-yellow-400' : ''
                    }`}
                  >
                    <Heart className="h-4 w-4 mr-1" />
                    {post.likes.length}
                  </Button>
                  <Button variant="ghost" size="sm" className="text-blue-200 hover:text-yellow-400">
                    <MessageCircle className="h-4 w-4 mr-1" />
                    {getPostComments(post.id).length}
                  </Button>
                  <Button variant="ghost" size="sm" className="text-blue-200 hover:text-yellow-400">
                    <Share2 className="h-4 w-4 mr-1" />
                    Share
                  </Button>
                </div>

                <div className="space-y-2">
                  {getPostComments(post.id).map(comment => (
                    <div key={comment.id} className="bg-blue-900/30 p-3 rounded border border-blue-700">
                      <div className="flex items-center space-x-2 mb-1">
                        <span className="font-semibold text-white text-sm">
                          {getUserName(comment.userId)}
                        </span>
                        <span className="text-xs text-blue-300">
                          {new Date(comment.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="text-blue-100 text-sm">{comment.content}</p>
                    </div>
                  ))}
                  
                  <div className="flex space-x-2">
                    <Input
                      placeholder="Add a comment..."
                      value={newComment[post.id] || ''}
                      onChange={(e) => setNewComment({ ...newComment, [post.id]: e.target.value })}
                      className="bg-blue-900/50 border-blue-600 text-white flex-1"
                    />
                    <Button
                      onClick={() => addComment(post.id)}
                      size="sm"
                      className="bg-gradient-to-r from-yellow-400 to-red-500 hover:from-yellow-500 hover:to-red-600"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};