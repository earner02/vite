import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';
import { AdminLogin } from './AdminLogin';
import { Shield } from 'lucide-react';

export const AdminButton: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button 
            className="bg-gradient-to-r from-yellow-500 to-red-600 hover:from-yellow-600 hover:to-red-700 text-white shadow-lg rounded-full p-3"
            size="sm"
          >
            <Shield className="h-5 w-5" />
          </Button>
        </DialogTrigger>
        <DialogContent className="bg-slate-900 border-slate-700 max-w-md">
          <AdminLogin onClose={() => setIsOpen(false)} />
        </DialogContent>
      </Dialog>
    </div>
  );
};