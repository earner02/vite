import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import { User, Post } from '@/types';
import { Shield, DollarSign, Users, Activity, Wallet, Edit } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

export const AdminPanel: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [fundAmount, setFundAmount] = useState('');
  const [adminWallet, setAdminWallet] = useState(0);
  const { updateUserWallet } = useAuth();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    const storedUsers = JSON.parse(localStorage.getItem('earnpost_users') || '[]');
    const storedPosts = JSON.parse(localStorage.getItem('earnpost_posts') || '[]');
    const storedAdminWallet = parseFloat(localStorage.getItem('earnpost_admin_wallet') || '100000');
    
    setUsers(storedUsers);
    setPosts(storedPosts);
    setAdminWallet(storedAdminWallet);
  };

  const handleApproveUser = (userId: string) => {
    const updatedUsers = users.map(user => 
      user.id === userId ? { ...user, isApproved: true } : user
    );
    setUsers(updatedUsers);
    localStorage.setItem('earnpost_users', JSON.stringify(updatedUsers));
    toast({ title: 'Success', description: 'User approved successfully' });
  };

  const handleBlockUser = (userId: string) => {
    const updatedUsers = users.map(user => 
      user.id === userId ? { ...user, isBlocked: !user.isBlocked } : user
    );
    setUsers(updatedUsers);
    localStorage.setItem('earnpost_users', JSON.stringify(updatedUsers));
    toast({ title: 'Success', description: 'User status updated' });
  };

  const handleAddFunds = () => {
    if (!selectedUser || !fundAmount || parseFloat(fundAmount) <= 0) {
      toast({ title: 'Error', description: 'Please select user and enter valid amount', variant: 'destructive' });
      return;
    }

    const amount = parseFloat(fundAmount);
    if (amount > adminWallet) {
      toast({ title: 'Error', description: 'Insufficient admin funds', variant: 'destructive' });
      return;
    }

    updateUserWallet(selectedUser.id, amount);
    const newAdminWallet = adminWallet - amount;
    setAdminWallet(newAdminWallet);
    localStorage.setItem('earnpost_admin_wallet', newAdminWallet.toString());
    
    setFundAmount('');
    setSelectedUser(null);
    loadData();
    toast({ title: 'Success', description: `E${amount} added to ${selectedUser.name}'s wallet` });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-950 via-blue-900 to-blue-800 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-center mb-6">
          <div className="relative mr-3">
            <Shield className="h-8 w-8 text-white" />
            <DollarSign className="h-4 w-4 text-yellow-400 absolute top-2 left-2" />
          </div>
          <h1 className="text-2xl font-bold text-white">Admin Dashboard</h1>
        </div>
        
        <div className="mb-6">
          <Card className="bg-blue-950/90 border-blue-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Wallet className="h-5 w-5 text-yellow-400 mr-2" />
                  <span className="text-white font-medium">Admin Wallet:</span>
                </div>
                <span className="text-yellow-400 font-bold text-lg">E{adminWallet.toFixed(2)}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="users" className="space-y-4">
          <TabsList className="bg-blue-900/50 border-blue-600">
            <TabsTrigger value="users" className="text-white data-[state=active]:bg-blue-700">Users</TabsTrigger>
            <TabsTrigger value="funds" className="text-white data-[state=active]:bg-blue-700">Add Funds</TabsTrigger>
            <TabsTrigger value="posts" className="text-white data-[state=active]:bg-blue-700">Posts</TabsTrigger>
          </TabsList>

          <TabsContent value="users">
            <div className="grid gap-4">
              {users.map(user => (
                <Card key={user.id} className="bg-blue-950/90 border-blue-700">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-white font-medium">{user.name}</h3>
                        <p className="text-blue-200 text-sm">{user.email}</p>
                        <p className="text-yellow-400 text-sm">Wallet: E{user.wallet.toFixed(2)}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={user.isApproved ? "default" : "secondary"}>
                          {user.isApproved ? 'Approved' : 'Pending'}
                        </Badge>
                        <Badge variant={user.isBlocked ? "destructive" : "default"}>
                          {user.isBlocked ? 'Blocked' : 'Active'}
                        </Badge>
                        {!user.isApproved && (
                          <Button size="sm" onClick={() => handleApproveUser(user.id)}
                            className="bg-green-600 hover:bg-green-700">
                            Approve
                          </Button>
                        )}
                        <Button size="sm" variant="outline" onClick={() => handleBlockUser(user.id)}
                          className="border-blue-600 text-white hover:bg-blue-700">
                          {user.isBlocked ? 'Unblock' : 'Block'}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="funds">
            <Card className="bg-blue-950/90 border-blue-700">
              <CardHeader>
                <CardTitle className="text-white">Add Funds to User</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-white">Select User</Label>
                  <select 
                    className="w-full p-2 bg-blue-900/50 border-blue-600 text-white rounded"
                    value={selectedUser?.id || ''}
                    onChange={(e) => {
                      const user = users.find(u => u.id === e.target.value);
                      setSelectedUser(user || null);
                    }}
                  >
                    <option value="">Select a user...</option>
                    {users.filter(u => u.isApproved && !u.isBlocked).map(user => (
                      <option key={user.id} value={user.id}>
                        {user.name} - E{user.wallet.toFixed(2)}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <Label className="text-white">Amount (E)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    value={fundAmount}
                    onChange={(e) => setFundAmount(e.target.value)}
                    className="bg-blue-900/50 border-blue-600 text-white"
                    placeholder="Enter amount"
                  />
                </div>
                <Button onClick={handleAddFunds}
                  className="bg-gradient-to-r from-yellow-400 to-red-500 hover:from-yellow-500 hover:to-red-600">
                  Add Funds
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="posts">
            <div className="grid gap-4">
              {posts.map(post => (
                <Card key={post.id} className="bg-blue-950/90 border-blue-700">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <p className="text-white mb-2">{post.content}</p>
                        <p className="text-blue-200 text-sm">By: {post.authorName}</p>
                        <p className="text-yellow-400 text-sm">Earnings: E{post.earnings?.toFixed(2) || '0.00'}</p>
                      </div>
                      <Button size="sm" variant="outline"
                        className="border-blue-600 text-white hover:bg-blue-700">
                        <Edit className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};