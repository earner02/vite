import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { Eye, EyeOff, Shield, DollarSign, Settings } from 'lucide-react';
import { AdminLoginModal } from '@/components/AdminLoginModal';

interface AuthFormProps {
  onSuccess?: () => void;
}

export const AuthForm: React.FC<AuthFormProps> = ({ onSuccess }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [passcode, setPasscode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  
  const { login, register } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      let success = false;
      if (isLogin) {
        success = await login(email, password);
      } else {
        if (!name || !passcode) {
          alert('Please fill all fields');
          return;
        }
        success = await register(email, password, name, passcode);
      }
      
      if (success && onSuccess) {
        onSuccess();
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-950 via-blue-900 to-blue-800 flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-blue-950/90 border-blue-700 backdrop-blur">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center mb-4">
            <div className="relative">
              <Shield className="h-12 w-12 text-white" />
              <DollarSign className="h-6 w-6 text-yellow-400 absolute top-3 left-3" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold text-white mb-2">EARNPOST</CardTitle>
          <p className="text-yellow-400 text-sm font-medium mb-2">EARN. SHARE. CONNECT.</p>
          <CardDescription className="text-blue-200">
            {isLogin ? 'Welcome back' : 'Join the community'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="email" className="text-white">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="bg-blue-900/50 border-blue-600 text-white placeholder-blue-300"
              />
            </div>
            
            <div>
              <Label htmlFor="password" className="text-white">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="bg-blue-900/50 border-blue-600 text-white placeholder-blue-300 pr-10"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3 text-blue-300 hover:text-white"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </Button>
              </div>
            </div>
            
            {!isLogin && (
              <>
                <div>
                  <Label htmlFor="name" className="text-white">Full Name</Label>
                  <Input
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    className="bg-blue-900/50 border-blue-600 text-white placeholder-blue-300"
                  />
                </div>
                <div>
                  <Label htmlFor="passcode" className="text-white">Transaction Passcode (4 digits)</Label>
                  <Input
                    id="passcode"
                    type="password"
                    maxLength={4}
                    value={passcode}
                    onChange={(e) => setPasscode(e.target.value.replace(/\D/g, ''))}
                    required
                    className="bg-blue-900/50 border-blue-600 text-white placeholder-blue-300"
                  />
                </div>
              </>
            )}
            
            <Button 
              type="submit" 
              className="w-full bg-gradient-to-r from-yellow-400 to-red-500 hover:from-yellow-500 hover:to-red-600 text-white font-semibold"
              disabled={loading}
            >
              {loading ? 'Processing...' : (isLogin ? 'Login' : 'Register')}
            </Button>
          </form>
          
          <div className="mt-4 text-center">
            <Button
              variant="link"
              onClick={() => setIsLogin(!isLogin)}
              className="text-yellow-400 hover:text-yellow-300"
            >
              {isLogin ? 'Need an account? Register' : 'Have an account? Login'}
            </Button>
          </div>
          
          <div className="mt-4 text-center border-t border-blue-600 pt-4">
            <Button
              variant="outline"
              onClick={() => setShowAdminLogin(true)}
              className="w-full bg-blue-800/50 border-blue-600 text-blue-200 hover:bg-blue-700/50 hover:text-white"
            >
              <Settings className="h-4 w-4 mr-2" />
              Admin Login
            </Button>
          </div>
          
          {!isLogin && (
            <div className="mt-4 p-3 bg-blue-900/30 border border-blue-600 rounded text-blue-200 text-sm">
              <p className="text-yellow-400 font-medium mb-1">Important:</p>
              <p>After registration, your account will need admin approval before you can access the platform.</p>
            </div>
          )}
        </CardContent>
      </Card>
      
      <AdminLoginModal 
        isOpen={showAdminLogin}
        onClose={() => setShowAdminLogin(false)}
        onSuccess={onSuccess}
      />
    </div>
  );
};