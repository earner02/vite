export interface User {
  id: string;
  email: string;
  password: string;
  passcode: string;
  name: string;
  wallet: number;
  isApproved: boolean;
  isBlocked: boolean;
  createdAt: Date;
}

export interface Post {
  id: string;
  userId: string;
  authorName: string;
  content: string;
  imageUrl?: string;
  videoUrl?: string;
  likes: string[];
  earnings?: number;
  createdAt: Date;
}

export interface Comment {
  id: string;
  postId: string;
  userId: string;
  content: string;
  createdAt: Date;
}

export interface Transaction {
  id: string;
  fromUserId: string;
  toUserId: string;
  amount: number;
  fee: number;
  type: 'p2p' | 'admin_fund' | 'withdrawal' | 'fee_collection';
  status: 'pending' | 'completed' | 'failed';
  createdAt: Date;
}

export interface AdminRequest {
  id: string;
  userId: string;
  type: 'funding' | 'withdrawal';
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: Date;
}