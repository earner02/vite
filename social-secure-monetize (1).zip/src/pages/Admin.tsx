import React, { useState } from 'react';
import { AdminLogin } from '@/components/AdminLogin';
import { AdminDashboard } from '@/components/AdminDashboard';
import { useAuth } from '@/contexts/AuthContext';

const Admin: React.FC = () => {
  const { isAdmin } = useAuth();
  const [showDashboard, setShowDashboard] = useState(isAdmin);

  const handleLoginSuccess = () => {
    setShowDashboard(true);
  };

  if (showDashboard || isAdmin) {
    return <AdminDashboard />;
  }

  return <AdminLogin onSuccess={handleLoginSuccess} />;
};

export default Admin;