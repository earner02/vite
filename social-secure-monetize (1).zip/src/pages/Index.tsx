import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { AuthForm } from '@/components/AuthForm';
import { MainApp } from '@/components/MainApp';

const Index = () => {
  const { user } = useAuth();

  if (!user || !user.isApproved) {
    return <AuthForm />;
  }

  return <MainApp />;
};

export default Index;